import lightning.pytorch as pl
import matplotlib.pyplot as plt
import pandas as pd
from lightning.pytorch.callbacks import ModelCheckpoint
from dataset import ElectricityDataModule
from dlinear import Dlinear
import torch
from torch import nn
from lightning.pytorch.callbacks import EarlyStopping

for i in range(15):
    data_df = pd.read_excel('cd-data.xlsx',sheet_name=str(i+1))
    data_df.drop(columns=['date'],inplace=True)
    num_features = data_df.shape[1]
    data_splits = {
            "train": 0.7,
            "val": 0.15,
            "predict": 0.15
        }
    pred_horizon = 12
    batch_size=32
    hid_size = 64
    n_layers = 3
    num_filters = 3

    time_window=10
    time_windows=[96]
    run_name = f"{pred_horizon}-Dlinear-化工-Y"+str(i)


    for time_window in time_windows:

        elec_dm = ElectricityDataModule(
            dataset_splits=data_splits,
            batch_size=batch_size,
            window_size=time_window,
            pred_horizon=pred_horizon,
            data_style="custom",
            data=data_df
        )

        name = f'{run_name}-tw'+str(time_window)

        

        checkpoint_loss_tpalstm = ModelCheckpoint(
            dirpath=f"checkpoints/{run_name}",
            filename=name,
            save_top_k=1,
            monitor="val/loss",
            mode="min"
        )


        early_stop_callback = EarlyStopping(
            monitor='val/loss',  # 指定监控指标
            min_delta=0.00,  # 指标提升的最小变化量
            patience=2,  # 没有提升时的等待轮数
            verbose=True,
            mode='min'
        )

        tpalstm_trainer = pl.Trainer(
            max_epochs=100,
            # accelerator='gpu',
            callbacks=[checkpoint_loss_tpalstm,early_stop_callback],
            #callbacks=[checkpoint_loss_tpalstm],
            strategy='auto',
            devices=1,
            # logger=wandb_logger_tpalstm
        )

        tpa_lstm = Dlinear(
            seq_len=time_window,
            pred_len=pred_horizon,
            enc_in=num_features,
            lr=1e-3,
            #num_heads=2
        )
        # tpa_lstm.eval()
        # input=torch.rand(batch_size,time_window,num_features)
        # out=tpa_lstm(input)
        
        tpalstm_trainer.fit(tpa_lstm, elec_dm)