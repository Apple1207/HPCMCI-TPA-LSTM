import torch
from torch import nn, optim
import lightning.pytorch as pl
from util import RMSE, RSE, CORR
 
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


    
class GABP(pl.LightningModule):
 
    def __init__(self, input_size, output_horizon, num_filters, hidden_size, obs_len, n_layers, lr=1e-3,num_y=1):
        super(GABP, self).__init__()
        self.num_y=num_y
        self.relu = nn.ReLU()

        self.hidden_size = hidden_size
        self.filter_num = num_filters
        self.filter_size = 1 # Don't change this - otherwise CNN filters no longer 1D
        self.output_horizon = output_horizon

        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, output_horizon*num_y)



        self.n_layers = n_layers
 
        self.lr = lr
        self.criterion = nn.MSELoss()
        
        self.save_hyperparameters()
 
 
    def forward(self, x):
        batch_size, obs_len, f_dim = x.size()
 
        H = torch.tanh(self.fc1(x))
        H = H[:, -1, :]
        H = torch.tanh(self.fc2(H))

        #new_ht = self.attention(H, htt)
        ypred = self.fc3(H)
        ypred = ypred.view(batch_size,self.output_horizon, self.num_y)
#         ypred = self.mlp_out(new_ht).unsqueeze(-1)
 
        return ypred
    

    def training_step(self, batch, batch_idx):
        inputs, label = batch 
        outputs = self.forward(inputs)
        loss = self.criterion(outputs, label)
        corr = CORR(outputs, label)
        rse = RSE(outputs, label)

        self.log("train/loss", loss, prog_bar=True, on_epoch=True, on_step=False)
        self.log("train/corr", corr, prog_bar=True, on_epoch=True, on_step=False)
        self.log("train/rse", rse, prog_bar=True, on_epoch=True, on_step=False)

        return loss
    
    def validation_step(self, batch, batch_idx):
        inputs, label = batch 

        outputs = self.forward(inputs)
        loss = self.criterion(outputs, label)
        corr = CORR(outputs, label)
        rse = RSE(outputs, label)

        self.log("val/loss", loss, prog_bar=True, on_epoch=True, on_step=False)
        self.log("val/corr", corr, prog_bar=True, on_epoch=True, on_step=False)
        self.log("val/rse", rse, prog_bar=True, on_epoch=True, on_step=False)

    def predict_step(self, batch, batch_idx):
        inputs, label = batch 
        pred = self.forward(inputs)

        return pred
    
    def configure_optimizers(self):
        optimiser = optim.Adam(
            self.parameters(),
            lr=self.lr,
            amsgrad=False,
#             weight_decay=1e-4,
        )
        return optimiser


 
