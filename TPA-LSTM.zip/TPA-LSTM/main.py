import lightning.pytorch as pl
import matplotlib.pyplot as plt
import pandas as pd
from lightning.pytorch.callbacks import ModelCheckpoint
from dataset import ElectricityDataModule
from tpa_lstm import TPALSTM
import torch
from torch import nn
from lightning.pytorch.callbacks import EarlyStopping
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"  # 解决MacOS系统下的问题

data_df = pd.read_csv('sample_hpcmci.csv')
#data_df = pd.read_csv('sample_HG.csv',index_col=['1'])
num_y=1
time_window=60
num_features = data_df.shape[1]


data_splits = {
    "train": 0.7,
    "val": 0.15,
    "predict": 0.15
}

pred_horizon = 12

elec_dm = ElectricityDataModule(
    dataset_splits=data_splits,
    batch_size=64,
    window_size=time_window,
    pred_horizon=pred_horizon,
    data_style="custom",
    data=data_df,
    num_y=num_y
)

run_name = f"{pred_horizon}-参数优化"

hid_size = 32
n_layers = 2
num_filters = 8
lr = 0.00054

name = f'{run_name}-TPA-LSTM'
checkpoint_loss_tpalstm = ModelCheckpoint(
    dirpath=f"checkpoints/{run_name}",
    filename=name,
    save_top_k=1,
    monitor="val/loss",
    mode="min"
)


early_stop_callback = EarlyStopping(
    monitor='val/loss',  # 指定监控指标
    min_delta=0.00,  # 指标提升的最小变化量
    patience=2,  # 没有提升时的等待轮数
    verbose=True,
    mode='min'
)

tpalstm_trainer = pl.Trainer(
    max_epochs=100,
    # accelerator='gpu',
    callbacks=[checkpoint_loss_tpalstm,early_stop_callback],
    strategy='auto',
    devices=1,
    # logger=wandb_logger_tpalstm
)

tpa_lstm = TPALSTM(
    input_size=num_features,
    hidden_size=hid_size,
    output_horizon=pred_horizon,
    num_filters=num_filters,
    obs_len=time_window,
    n_layers=n_layers,
    lr=lr,
    num_y=num_y
)

#tpalstm_trainer.fit(tpa_lstm, elec_dm)

lossfun = nn.MSELoss()

elec_dm.setup("predict")
run_to_load = run_name
model_path = f"checkpoints/{run_to_load}/{name}.ckpt"
tpa_lstm = TPALSTM.load_from_checkpoint(model_path)

pred_dl = elec_dm.predict_dataloader()
y_pred = tpalstm_trainer.predict(tpa_lstm, pred_dl)

batch_idx = 0

Yture=[]
Ypred=[]
Loss=[]
for i, batch in enumerate(pred_dl):
    inputs, labels = batch
    X, ytrue = inputs[batch_idx][:, -1],  labels[batch_idx].squeeze()
    ypred = y_pred[i][batch_idx].squeeze()
    Yture.append(ytrue)
    Ypred.append(ypred)
    X = X.cpu().numpy()
    loss_vali_temp = lossfun(ypred, ytrue)
    Loss.append(loss_vali_temp)
    print('The validation quality is:', loss_vali_temp)

    ytrue = ytrue.cpu().numpy()
    ypred = ypred.cpu().numpy()
    

    # plt.figure(figsize=(8, 4))
    # plt.plot(range(0, 24), X, label="Input")
    # plt.scatter(range(24, 24 + pred_horizon), ytrue, color='cornflowerblue', label="True-Value")
    # plt.scatter(range(24, 24 + pred_horizon), ypred, marker="x", color='green', label="TPA-LSTM pred")
    # plt.legend(loc="lower left")
    # plt.savefig("preds")
    # plt.show()

stacked_tensor =torch.stack(Loss)
mean_value = torch.mean(stacked_tensor)
print(mean_value)
