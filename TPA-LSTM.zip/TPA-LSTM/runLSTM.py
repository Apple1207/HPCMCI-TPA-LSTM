import lightning.pytorch as pl
import pandas as pd
from lightning.pytorch.callbacks import ModelCheckpoint
from dataset import ElectricityDataModule
from lstm import TPALSTM
import torch
from torch import nn
from lightning.pytorch.callbacks import EarlyStopping
import numpy as np
import matplotlib.pyplot as plt
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"  # 解决MacOS系统下的问题

data_df = pd.read_csv('hpcmci.csv')
num_y = 1
time_window = 60
num_features = data_df.shape[1]

data_splits = {
    "train": 0.7,
    "val": 0.15,
    "predict": 0.15
}

pred_horizon = 96

elec_dm = ElectricityDataModule(
    dataset_splits=data_splits,
    batch_size=64,
    window_size=time_window,
    pred_horizon=pred_horizon,
    data_style="custom",
    data=data_df,
    num_y=num_y
)

run_name = f"{pred_horizon}"

hid_size = 32
lr = 0.0001
num_filters = 3
n_layers = 2

dirpath="NewCheckpoints/"

name = f'{run_name}-CD-LSTM'
checkpoint_loss_tpalstm = ModelCheckpoint(
    dirpath=dirpath,
    filename=name,
    save_top_k=1,
    monitor="val/loss",
    mode="min"
)

early_stop_callback = EarlyStopping(
    monitor='val/loss',
    min_delta=0.00,
    patience=2,
    verbose=True,
    mode='min'
)

tpalstm_trainer = pl.Trainer(
    max_epochs=20,
    callbacks=[checkpoint_loss_tpalstm, early_stop_callback],
    strategy='auto',
    devices=1
)

tpa_lstm = TPALSTM(
    input_size=num_features,
    hidden_size=hid_size,
    output_horizon=pred_horizon,
    num_filters=num_filters,
    obs_len=time_window,
    n_layers=n_layers,
    lr=lr,
    num_y=num_y
)
tpalstm_trainer.fit(tpa_lstm, elec_dm)

lossfun = nn.MSELoss()

elec_dm.setup("predict")
run_to_load = name
model_path = dirpath+ f"{run_to_load}.ckpt"
tpa_lstm = TPALSTM.load_from_checkpoint(model_path)

pred_dl = elec_dm.predict_dataloader()
y_pred = tpalstm_trainer.predict(tpa_lstm, pred_dl)

Ytrue = []
Ypred = []
Loss = []
for i, batch in enumerate(pred_dl):
    inputs, labels = batch
    X, ytrue = inputs[:][:, -1], labels[:].squeeze()
    ypred = y_pred[i][:].squeeze()
    if ytrue.cpu().numpy().ndim==1:
        continue
    Ytrue.append(ytrue.cpu().numpy())
    Ypred.append(ypred.cpu().numpy())
    X = X.cpu().numpy()
    loss_vali_temp = lossfun(ypred, ytrue)
    Loss.append(loss_vali_temp)
    print('The validation quality is:', loss_vali_temp)

stacked_tensor = torch.stack(Loss)
mean_value = torch.mean(stacked_tensor)
print(mean_value)

# Convert lists to 2D NumPy arrays
Ytrue = np.concatenate(Ytrue, axis=0)
Ypred = np.concatenate(Ypred, axis=0)

plt.figure(figsize=(10, 6))
plt.plot(Ytrue[:, -1], label='Array a (First Column)')
plt.plot(Ypred[:, -1], label='Array b (First Column)')
plt.show()

# Save or process Ytrue and Ypred as needed
# For example, to save them:
np.save('Ytrue.npy', Ytrue)
np.save('Ypred.npy', Ypred)

mse = np.mean((Ytrue - Ypred) ** 2)
print("MSE:", mse)
mae = np.mean(np.abs(Ytrue - Ypred))
print("MAE:", mae)

y_true_torch = torch.tensor(Ytrue, dtype=torch.float32)
y_pred_torch = torch.tensor(Ypred, dtype=torch.float32)

# 实例化MSELoss
mse_loss_fn = nn.MSELoss()

# 计算MSE
mse = mse_loss_fn(y_pred_torch, y_true_torch)
print("MSE:", mse.item())  # 使用.item()将单个元素张量转换为Python数字

# 计算MAE
mae = torch.mean(torch.abs(y_pred_torch - y_true_torch)).item()
print("MAE:", mae)  # 使用.item()将单个元素张量转换为Python数字