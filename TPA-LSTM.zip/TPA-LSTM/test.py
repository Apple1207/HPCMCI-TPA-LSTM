import torch
import torch.nn as nn
import pytorch_lightning as pl
from torch.utils.data import DataLoader, TensorDataset

class LinearEncoder(nn.Module):
    def __init__(self, input_size, encoding_size):
        super(LinearEncoder, self).__init__()
        self.linear = nn.Linear(input_size, encoding_size)

    def forward(self, x):
        return self.linear(x)

class LinearDecoder(nn.Module):
    def __init__(self, encoding_size, output_size):
        super(LinearDecoder, self).__init__()
        self.linear = nn.Linear(encoding_size, output_size)

    def forward(self, x):
        return self.linear(x)

class PredictionModel(pl.LightningModule):
    def __init__(self, input_size, encoding_size, prediction_length):
        super(PredictionModel, self).__init__()
        self.save_hyperparameters()
        self.encoder = LinearEncoder(input_size, encoding_size)
        self.decoder = LinearDecoder(encoding_size, input_size * 60)  # 注意这里的输出尺寸
        self.prediction_head = nn.Linear(encoding_size, prediction_length)

    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded).view(-1, 60, self.hparams.input_size)  # 调整尺寸以匹配输入
        prediction = self.prediction_head(encoded)
        return decoded, prediction

    def training_step(self, batch, batch_idx):
        x, y = batch
        x_seq, prediction = self(x)
        loss_seq = nn.MSELoss()(x_seq, x[:, :-1, :])  # 序列重建损失
        loss_prediction = nn.MSELoss()(prediction, y)  # 预测损失
        loss = loss_seq + loss_prediction
        self.log('train_loss', loss)
        return loss

    def validation_step(self, batch, batch_idx):
        x, y = batch
        x_seq, prediction = self(x)
        loss_seq = nn.MSELoss()(x_seq, x[:, :-1, :])  # 序列重建损失
        loss_prediction = nn.MSELoss()(prediction, y)  # 预测损失
        loss = loss_seq + loss_prediction
        self.log('val_loss', loss)
        return loss

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), lr=1e-3)
        return optimizer

def create_dummy_data(batch_size, input_size, sequence_length, prediction_length):
    x = torch.randn(batch_size, sequence_length, input_size)
    y = torch.randn(batch_size, prediction_length)
    dataset = TensorDataset(x, y)
    return dataset

model = PredictionModel(input_size=6, encoding_size=5, prediction_length=1)

batch_size = 32
sequence_length = 60
dataset = create_dummy_data(batch_size, 6, sequence_length, 1)
train_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)

model.train_dataloader = lambda: train_loader
model.val_dataloader = lambda: val_loader

trainer = pl.Trainer(max_epochs=1)
trainer.fit(model)