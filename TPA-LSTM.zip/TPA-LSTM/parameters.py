import optuna
import lightning.pytorch as pl
from lightning.pytorch.callbacks import ModelCheckpoint, EarlyStopping
import pandas as pd
from dataset import ElectricityDataModule
from tpa_lstm import TPALSTM
import torch.nn as nn
import optuna.visualization as vis

# 数据加载
data_df = pd.read_csv('hpcmci.csv')
num_y = 1
time_window = 60
num_features = data_df.shape[1]

data_splits = {
    "train": 0.7,
    "val": 0.15,
    "predict": 0.15
}

pred_horizon = 96
elec_dm = ElectricityDataModule(
    dataset_splits=data_splits,
    batch_size=64,
    window_size=time_window,
    pred_horizon=pred_horizon,
    data_style="custom",
    data=data_df,
    num_y=num_y
)

# 定义目标函数
def objective(trial):
    # 1. 定义要优化的超参数
    hid_size = trial.suggest_int("hidden_size", 32, 256, step=32)  # 隐藏层大小
    n_layers = trial.suggest_int("n_layers", 1, 3)  # LSTM 层数
    num_filters = trial.suggest_int("num_filters", 2, 10)  # 卷积滤波器数量
    lr = trial.suggest_loguniform("lr", 1e-4, 1e-2)  # 学习率

    # 2. 定义模型
    tpa_lstm = TPALSTM(
        input_size=num_features,
        hidden_size=hid_size,
        output_horizon=pred_horizon,
        num_filters=num_filters,
        obs_len=time_window,
        n_layers=n_layers,
        lr=lr,
        num_y=num_y
    )

    # 3. 定义回调函数
    checkpoint_callback = ModelCheckpoint(
        monitor="val/loss",
        mode="min",
        save_top_k=1,
        dirpath="checkpoints-参数优化",
        filename=f"{pred_horizon}"+"-{epoch:02d}-{val_loss:.2f}"
    )

    early_stop_callback = EarlyStopping(
        monitor="val/loss",
        patience=3,
        mode="min",
        verbose=True
    )

    # 4. 定义 Trainer
    trainer = pl.Trainer(
        max_epochs=50,
        devices=1,
        #accelerator="gpu",
        callbacks=[checkpoint_callback, early_stop_callback]
    )

    # 5. 模型训练
    trainer.fit(tpa_lstm, elec_dm)

    # 6. 验证集损失作为优化目标
    metrics = trainer.callback_metrics
    val_loss = metrics["val/loss"].item()

    return val_loss

# 启动 Optuna 超参数优化
study = optuna.create_study(direction="minimize")  # 目标是最小化验证集损失
study.optimize(objective, n_trials=30)

# 打印最佳超参数
print("Best trial:")
print(f"  Value: {study.best_trial.value}")
print(f"  Params: {study.best_trial.params}")

# 保存 Optuna 的最佳结果
study.trials_dataframe().to_csv("optuna_trials.csv", index=False)

# 可视化结果
# # 优化历史
# fig1 = vis.plot_optimization_history(study)
# fig1.show()

# # 超参数重要性
# fig2 = vis.plot_param_importances(study)
# fig2.show()

# # 平行坐标图
# fig3 = vis.plot_parallel_coordinate(study)
# fig3.show()

# # 参数分布
# fig4 = vis.plot_slice(study)
# fig4.show()

# # 保存可视化为 HTML 文件
# fig1.write_html("optimization_history.html")
# fig2.write_html("param_importances.html")
# fig3.write_html("parallel_coordinates.html")
# fig4.write_html("slice_plot.html")