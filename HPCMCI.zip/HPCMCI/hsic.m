function sta=hsic(kx,ky)

kxy=kx*ky;
n=size(kx,1);
h=trace(kxy)/n^2+mean(mean(kx))*mean(mean(ky))-2*mean(mean(kxy))/n;
sta=h*n^2/(n-1)^2;