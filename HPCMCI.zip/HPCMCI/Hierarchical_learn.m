 function [G,pval_matrix,hval_matrix]=Hierarchical_learn(sample,N_sample,sample_start,N,k,Pval,tau_max,tau_step,sta_stable)

% ������ʼ��
n=sum(N); %�ڵ���
parents=cell(n);
num_layer=numel(N); %�ܹ�����
N=[0,N]; %������ʼ�ڵ�
N=cumsum(N);
G=-ones(n);
timeLength=zeros(n);
pval_matrix=zeros(n);
hval_matrix=zeros(n);
tic
%% step1
% �жϸ����ڼ����ڲ��нڵ�֮��Ĺ�ϵ
% ����������������
for i=1:num_layer-1 %������-1�ּ���Ϳ�����
    i
    node1=N(i)+1:N(i+1); %�Ͳ�ڵ�Id 
    node2=N(i)+1:N(end); %�߲�ڵ�Id
    for ii=node1
        ii
        N1=node2(1);%���ڸ���taumin
        N2=N(i+2);%���ڸ���taumin
        tau_min=0;
        %���
        for iii=node2
            iii
            t1=tau_min;
            flag=0;
            stat_temp=0;
            statbest1=0;
            tbest1=0;
            for st=1:3
                %���ղ�ͬ�ľ�������
                step=tau_step(st); %ʱ�䲽��
                for t=t1:step:tau_max
                    sample1=[sample(sample_start:sample_start+N_sample,ii),sample(sample_start+t:sample_start+N_sample+t,iii)];
                    [pval,stat] = cond_indep_kernel(1, 2, [], sample1, []);
                    if pval<Pval
                        %����
                        if flag
                            if stat<sta_stable || stat<stat_temp
                                t_best=t_temp;
                                stat_best=stat_temp;
                                t1=max(t_best-ceil(step/4),0);
                                break
                            else
                                stat_temp=stat;
                                t_temp=t;
                            end
                        else
                            if stat<sta_stable
                                continue
                            else
                                stat_temp=stat;
                                t_temp=t;
                                if flag==0
                                    t_best=t_temp;
                                    stat_best=stat_temp;
                                end
                                flag=1;
                            end
                        end
                    end
                end
                if flag==0
                    break
                elseif stat_temp>statbest1
                    statbest1=stat_temp;
                    tbest1=t_best;
                end
            end
            if flag==1 %˵��ii����>iii�й�ϵ
                G(ii,iii)=tbest1;
                hval_matrix(ii,iii)=statbest1;
                pval_matrix(ii,iii)=1;
            end
            %���� tau_min
            if any(iii==N)
                %n��ʱ�ʹ��ڵ���n-1��
                temp=G(ii,N1:N2);
                temp=min(temp(temp>0));
                tau_min=max(0,temp);
            end
        end
    end
end
toc
a=1;

%% step 2
% MCIȥ����ʱ�Ͷ���ʱ�͵�Ӱ��
pzmax=1;
for i=1:num_layer-1 %������-1�ּ���Ϳ�����
    node1=N(i)+1:N(i+1); %�Ͳ�ڵ�Id 
    node2=N(i+1)+1:N(end); %�߲�ڵ�Id
    for ii=node1
        %���
        for iii=node2
            if pval_matrix(ii,iii)~=1
                continue
            end
            %����ͬʱ��ii��iii������px������
            nbrs1 = mysetdiff(find(pval_matrix(:,iii)), ii);
            nbrs1_temp=nbrs1;
            for iiii=1:numel(nbrs1)
                nbrs1_temp(iiii)=max(hval_matrix(ii,iiii),hval_matrix(iiii,ii));
            end
            nbrs1=nbrs1(logical(nbrs1_temp));
            val=nbrs1_temp(logical(nbrs1_temp));
            if numel(val)==0
                continue
            elseif numel(val)>pzmax
                [~,id]=sort(val);
                nbrs1=nbrs1(id(1:pzmax));
            end
            %ȡ��ǰpzmax������
            %��������
            n=numel(nbrs1);
            tmax=G(ii,iii);
            for iiii=1:n
                id=nbrs1(iiii);
                t=max(G(id,iii),G(iii,id));
                if t>tmax
                    tmax=t;
                end
            end
            datax=sample(sample_start+tmax-G(ii,iii):sample_start+N_sample+tmax-G(ii,iii),ii);
            datay=sample(sample_start+tmax:sample_start+N_sample+tmax,iii);
            
            for iiii=1:n
                id=nbrs1(iiii);
                t=max(G(id,iii),G(iii,id));
                dataz=sample(sample_start+tmax-t:sample_start+N_sample+tmax-t,id);
                sample1=[datax,datay,dataz];
                [pval,stat] = cond_indep_kernel(1, 2, 3, sample1, []);
                if pval>Pval || stat<sta_stable
                    G(ii,iii)=-1;
                    hval_matrix(ii,iii)=0;
                    pval_matrix(ii,iii)=0;
                    break
                end
            end
        end
    end
end
% pdag(pdag==1)=0;
% %%
% ii=40;
% iii=57;
% sample_start=5000;
% N_sample=1000;
% stat=0;
% %data1=data;
% for t=0:1:1000
%     t
%     sample1=[sample(sample_start:sample_start+N_sample,ii),sample(sample_start+t:sample_start+N_sample+t,iii)];
%     [pval,stat(t+1)] = cond_indep_kernel(1, 2, [], sample1, []);
% end
% plot(stat)

% %%
% figure
% plot(sample1(:,1))
% hold on
% plot(sample1(:,2))
