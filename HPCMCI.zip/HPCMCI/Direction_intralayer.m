function pdag=Direction_intralayer(G,node,k,sample,Pval)

G_origin=G;
sep = cell(node(end));
done=0;
ord=1;
while ~done
    if ord>k
        break
    end
    done = 1;
    [X,Y] = find(G);
    Y=Y(X>=node(1));
    X=X(X>=node(1));
    for i=1:length(X)
        x = X(i); y = Y(i);
        %nbrs = mysetdiff(myunion(neighbors(G, x), neighbors(G,y)), [x y]);
        nbrs = mysetdiff(neighbors(G, y), x);  % bug fix by Raanan Yehezkel <raanany@ee.bgu.ac.il> 6/27/04
        %nbrs = unique(nbrs); % bug fix Immer Ebert ebert@tree.com 3/278/11
        if length(nbrs) >= ord && G(x,y) ~= 0
            done = 0;
            %SS = subsets(nbrs, ord, ord); % all subsets of size ord
            SS = subsets1(nbrs, ord);
            for si=1:length(SS)
                S = SS{si};
                if feval('cond_indep_kernel', x, y, S, sample,[])>Pval
              
                    G(x,y) = 0;
                    G(y,x) = 0;
                    sep{x,y} = myunion(sep{x,y}, S);
                    sep{y,x} = myunion(sep{y,x}, S);
                    break; % no need to check any more subsets
                end
            end
        end
    end
    ord = ord + 1;
end

% Create the minimal pattern,
% i.e., the only directed edges are V structures.
pdag = G;
[X, Y] = find(G);
Y=Y(X>=node(1));X=X(X>=node(1));
% We want to generate all unique triples x,y,z
% This code generates x,y,z and z,y,x.
% x y z����ͬһ��ڵ�
for i=1:length(X)
    x = X(i);
    y = Y(i);
    Z = find(G(y,:));
    Z = mysetdiff(Z, x);
    Z = Z(Z>=node(1));
    for z=Z(:)'
        if G(x,z)==0 && ~ismember(y, sep{x,z}) && ~ismember(y, sep{z,x})
            %fprintf('%d -> %d <- %d\n', x, y, z);
            pdag(x,y) = -1; pdag(y,x) = 0;
            pdag(z,y) = -1; pdag(y,z) = 0;
        end
    end
end

%% abc
% G_origin=triu(G_origin,0);
% [X, Y]=find(G_origin);
% pdag_keda=keda(G);
% S=[];
% for i=1:length(X)
%     x = X(i);
%     y = Y(i);
%     if pdag_keda(x,y)==0
%         S=[S;x,y];  
%     end
% end
