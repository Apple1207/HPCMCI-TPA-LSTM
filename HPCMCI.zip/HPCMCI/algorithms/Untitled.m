sample1=sample(1:1000,:);
pval=zeros(15);
for i=1:15
    i
    for ii=i:15
        ii
        [pval(i,ii),~] = cond_indep_kernel(i, ii, [], sample1, []);
    end
end